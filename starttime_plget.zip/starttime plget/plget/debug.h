#ifndef PLGET_DEBUG_H
#define PLGET_DEBUG_H

void db_dump_buf(void *data, int size);
void pr_progress_bar(char label[], int step, int total);

#endif
